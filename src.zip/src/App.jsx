// src/App.jsx
import { useEffect, useRef, useState } from "react";
import { embedDashboard } from "@superset-ui/embedded-sdk";
import "./App.css";

// --- 您的設定 (保持不變) ---
const DASHBOARD_UUID = "ee9c1af3-7dd7-41af-97db-89893e0d5d94";
const SUPERSET_DOMAIN = "http://localhost:8088";
const BACKEND_API_URL = "http://localhost:8000/api/guest-token";

function App() {
  const dashboardMountPoint = useRef(null);
  // --- 修改點：使用 state 來儲存要篩選的州別 ---
  const [filterState, setFilterState] = useState("MA"); // 預設篩選 MA

  const fetchGuestToken = async (currentState) => {
    try {
      // --- 修改點：建立 RLS 規則並傳送到後端 ---
      const rls_rules = [
        {
          clause: `state = '${currentState}'`,
          dataset: 19, // 假設您的資料集 ID 是 19
        }
      ];

      const response = await fetch(BACKEND_API_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          dashboard_uuid: DASHBOARD_UUID,
          rls_rules: rls_rules, // <--- 將規則加入請求中
        }),
      });

      if (!response.ok) {
        throw new Error(`Failed to fetch guest token: ${response.statusText}`);
      }
      const { token } = await response.json();
      return token;
    } catch (error) {
      console.error("Error fetching guest token:", error);
      return null;
    }
  };

  // --- 修改點：讓 useEffect 監聽 filterState 的變化 ---
  useEffect(() => {
    const embed = async () => {
      if (dashboardMountPoint.current) {
        embedDashboard({
          id: DASHBOARD_UUID,
          supersetDomain: SUPERSET_DOMAIN,
          mountPoint: dashboardMountPoint.current,
          // 每次都用最新的 filterState 去獲取 token
          fetchGuestToken: () => fetchGuestToken(filterState),
          dashboardUiConfig: {
            hideTitle: true,
            hideChartControls: false,
            hideTab: true,
          },
        });
      }
    };
    embed();
  }, [filterState]); // <--- 當 filterState 改變時，重新執行 embed

  return (
    <div className="app-container">
      <h1>DEMO用途 React JS + Superset Embedded via SDK</h1>
      
      {/* --- 修改點：新增用於改變篩選條件的 UI --- */}
      <div style={{ padding: '10px 20px' }}>
        <p>Select State to Filter:</p>
        <button onClick={() => setFilterState('MA')}>Massachusetts (MA)</button>
        <button onClick={() => setFilterState('CA')}>California (CA)</button>
        <button onClick={() => setFilterState('NY')}>New York (NY)</button>
      </div>


      <div 
        ref={dashboardMountPoint}
        className="dashboard-container"
        style={{
          width: '195vw',
          height: '85vh',
          margin: '0 auto',
          border: '1px solid #444'
        }}
      />

    </div>
  );
}

export default App;